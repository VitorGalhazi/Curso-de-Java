module DeciBina {
	requires java.desktop;
}